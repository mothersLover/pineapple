package com.moneytransfer.core.config;

import com.moneytransfer.utils.PropertyReader;

public class BaseConfiguration {
    protected final String DAOMode;

    public BaseConfiguration(PropertyReader propertyReader) {
        this.DAOMode = propertyReader.getStringProperty("dao.mode", getDefaultDAOMode());
    }

    public static String getDefaultDAOMode() {
        return "h2";
    }

    public String getDAOMode() {
        return DAOMode;
    }
}
