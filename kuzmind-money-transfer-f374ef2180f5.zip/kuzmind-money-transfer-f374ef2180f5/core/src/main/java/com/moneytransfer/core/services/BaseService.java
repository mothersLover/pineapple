package com.moneytransfer.core.services;

import com.moneytransfer.core.config.BaseConfiguration;
import com.moneytransfer.datastorage.dao.api.DAOFactory;

abstract class BaseService {
    private final DAOFactory daoFactory;
    private BaseConfiguration baseConfiguration;

    public BaseService(DAOFactory daoFactory, BaseConfiguration baseConfiguration) {
        this.daoFactory = daoFactory;
        this.baseConfiguration = baseConfiguration;
    }

    public DAOFactory getDaoFactory() {
        return daoFactory;
    }

    public BaseConfiguration getBaseConfiguration() {
        return baseConfiguration;
    }
}
