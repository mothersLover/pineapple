package com.moneytransfer.datastorage.configs;

import com.moneytransfer.utils.PropertyReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class H2Config {
    private final String driver;
    private final String connectionUrl;
    private final String user;
    private final String password;

    private final String schemaFilePath;

    private static final String H2_DRIVER = "h2_driver";
    private static final String H2_CONNECTION_URL = "h2_connection_url";
    private static final String H2_PASSWORD = "h2_password";
    private static final String H2_USER = "h2_user";
    private static final String H2_SCHEMA = "h2_schema";
    private static Logger log = LoggerFactory.getLogger(H2Config.class);
    public H2Config(PropertyReader propertyReader) {
        driver = propertyReader.getStringProperty(H2_DRIVER);
        log.debug("Found property " + H2_DRIVER + " = " + driver);
        connectionUrl = propertyReader.getStringProperty(H2_CONNECTION_URL);
        log.debug("Found property " + H2_CONNECTION_URL + " = " + connectionUrl);
        user = propertyReader.getStringProperty(H2_USER);
        log.debug("Found property " + H2_USER + " = " + user);
        password = propertyReader.getStringProperty(H2_PASSWORD);
        log.debug("Found property " + H2_PASSWORD + " = " + password);
        schemaFilePath = propertyReader.getStringProperty(H2_SCHEMA);
        log.debug("Found property " + H2_SCHEMA + " = " + schemaFilePath);
    }

    public String getDriver() {
        return driver;
    }

    public String getConnectionUrl() {
        return connectionUrl;
    }

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getSchemaFilePath() {
        return schemaFilePath;
    }
}
