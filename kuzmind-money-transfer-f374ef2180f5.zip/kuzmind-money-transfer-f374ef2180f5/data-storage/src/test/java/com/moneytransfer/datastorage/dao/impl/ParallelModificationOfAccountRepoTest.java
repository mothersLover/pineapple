package com.moneytransfer.datastorage.dao.impl;

public class ParallelModificationOfAccountRepoTest {
}
