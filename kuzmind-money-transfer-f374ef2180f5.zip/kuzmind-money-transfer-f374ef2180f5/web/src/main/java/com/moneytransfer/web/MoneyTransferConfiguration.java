package com.moneytransfer.web;

import com.moneytransfer.utils.PropertyReader;

public class MoneyTransferConfiguration {
    private final int httpPort;
    private static final int DEFAULT_HTTP_PORT = 8080;
    private static final String HTTP_PORT_PROPERTY = "http.port";

    public MoneyTransferConfiguration(PropertyReader propertyReader) {
        httpPort = propertyReader.getIntegerProperty(HTTP_PORT_PROPERTY, DEFAULT_HTTP_PORT);
    }

    public int getHttpPort() {
        return httpPort;
    }
}
