package com.moneytransfer.web.jersey;

import com.moneytransfer.web.response.ErrorResponse;
import org.glassfish.jersey.server.validation.ValidationError;
import org.glassfish.jersey.server.validation.internal.ValidationHelper;

import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.stream.Collectors;

/**
 * Catches ConstraintViolationException and allows to construct proper http response
 * that matches general error response json scheme.
 */
@Provider
public class ConstraintViolationExceptionMapper implements ExceptionMapper<ConstraintViolationException> {
    @Override
    public Response toResponse(ConstraintViolationException cve) {
        Response.Status badRequestError = Response.Status.BAD_REQUEST;
        return Response
                .status(badRequestError)
                .entity(new ErrorResponse(badRequestError, collectViolations(cve)))
                .type(MediaType.APPLICATION_JSON)
                .build();
    }

    private String collectViolations(ConstraintViolationException cve) {
        return ValidationHelper
                .constraintViolationToValidationErrors(cve)
                .stream()
                .map(ValidationError::getMessage)
                .collect(Collectors.joining(", "));
    }
}
